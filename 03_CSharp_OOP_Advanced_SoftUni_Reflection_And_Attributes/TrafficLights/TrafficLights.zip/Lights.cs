﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrafficLights
{
    enum Lights
    {
        Red,Green,Yellow
    } 
}
