﻿using TheCommandsStrikeBack.Core.Commands;

namespace TheCommandsStrikeBack.Core
{
    using System;
    using Contracts;

    class Engine : IRunnable
    {
        private IRepository repository;
        private IUnitFactory unitFactory;

        public Engine(IRepository repository, IUnitFactory unitFactory)
        {
            this.repository = repository;
            this.unitFactory = unitFactory;
        }
        
        public void Run()
        {
            while (true)
            {
                try
                {
                    string input = Console.ReadLine();
                    string[] data = input.Split();
                    string commandName = data[0];
                    string result = InterpredCommand(data, commandName);
                    Console.WriteLine(result);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        // TODO: refactor for Problem 4
        private string InterpredCommand(string[] data, string commandName)
        {
            string result = string.Empty;
            switch (commandName)
            {
                case "add":
                    AddUnitCommand addCommand = new AddUnitCommand(data, repository, unitFactory);
                    result = addCommand.Execute();
                    break;
                case "report":
                    ReportCommand reportCommand = new ReportCommand(data, repository, unitFactory);
                    result = reportCommand.Execute();
                    break;
                case "retire":
                    RetireCommand retireCommand = new RetireCommand(data, repository, unitFactory);
                    result = retireCommand.Execute();
                    break;
                case "fight":
                    Environment.Exit(0);
                    break;
                default:
                    throw new InvalidOperationException("Invalid command!");
            }
            return result;
        }


        
    }
}
