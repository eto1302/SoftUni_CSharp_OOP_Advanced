﻿namespace TheCommandsStrikeBack.Contracts
{
    public interface IAttacker
    {
        int AttackDamage { get; }
    }
}
