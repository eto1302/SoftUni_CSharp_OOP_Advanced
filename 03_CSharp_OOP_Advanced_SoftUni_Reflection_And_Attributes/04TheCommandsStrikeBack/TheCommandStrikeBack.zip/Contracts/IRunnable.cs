﻿namespace TheCommandsStrikeBack.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
