﻿namespace TheCommandsStrikeBack.Contracts
{
    public interface IExecutable
    {
        string Execute();
    }
}
