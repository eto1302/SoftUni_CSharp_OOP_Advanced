﻿namespace TheCommandsStrikeBack.Contracts
{
    public interface IDestroyable
    {
        int Health { get; set; }
    }
}
